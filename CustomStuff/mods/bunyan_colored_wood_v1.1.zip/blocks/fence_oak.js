// Fence Config
id = config.getBlockId("fence_oakID");	   
name = "fence_oak";
displayName[0]   = "Oak Fence Gate";   

// Texture Information
textureFile = "wood.png";
textureIndexXN[0]   = 16;
textureIndexXP[0]   = 16;
textureIndexYN[0]   = 32;	   
textureIndexYP[0]   = 32;
textureIndexZN[0]   = 16;
textureIndexZP[0]   = 16;

drop[0] = config.getBlockId("fence_oakID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;
material = "wood";
stepSound = "wood";
