// Fence Config
id = config.getBlockId("fence_acaciaID");	   
name = "fence_acacia";
displayName[0]   = "Acacia Wood Fence Gate";   

// Texture Information
textureFile = "wood.png";
textureIndexXN[0]   = 22;
textureIndexXP[0]   = 22;
textureIndexYN[0]   = 38;	   
textureIndexYP[0]   = 38;
textureIndexZN[0]   = 22;
textureIndexZP[0]   = 22;

drop[0] = config.getBlockId("fence_acaciaID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;
material = "wood";
stepSound = "wood";
