// Fence Config
id = config.getBlockId("fence_acacia_plankID");	   
name = "fence_acacia_plank";
displayName[0]   = "Acacia Plank Fence Gate";   

// Texture Information
textureFile = "wood.png";
textureIndexXN[0]   = 6;
textureIndexXP[0]   = 6;
textureIndexYN[0]   = 6;	   
textureIndexYP[0]   = 6;
textureIndexZN[0]   = 6;
textureIndexZP[0]   = 6;

drop[0] = config.getBlockId("fence_acacia_plankID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;
material = "wood";
stepSound = "wood";
