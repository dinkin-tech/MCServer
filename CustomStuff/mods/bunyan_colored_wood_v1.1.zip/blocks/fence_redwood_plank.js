// Fence Config
id = config.getBlockId("fence_redwood_plankID");	   
name = "fence_redwood_plank";
displayName[0]   = "Redwood Plank Fence Gate";   

// Texture Information
textureFile = "wood.png";
textureIndexXN[0]   = 4;
textureIndexXP[0]   = 4;
textureIndexYN[0]   = 4;	   
textureIndexYP[0]   = 4;
textureIndexZN[0]   = 4;
textureIndexZP[0]   = 4;

drop[0] = config.getBlockId("fence_redwood_plankID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;
material = "wood";
stepSound = "wood";
