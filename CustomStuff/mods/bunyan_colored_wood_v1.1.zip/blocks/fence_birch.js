// Fence Config
id = config.getBlockId("fence_birchID");	   
name = "fence_birch";
displayName[0]   = "Birch Fence Gate";   

// Texture Information
textureFile = "wood.png";
textureIndexXN[0]   = 18;
textureIndexXP[0]   = 18;
textureIndexYN[0]   = 32;	   
textureIndexYP[0]   = 32;
textureIndexZN[0]   = 18;
textureIndexZP[0]   = 18;

drop[0] = config.getBlockId("fence_birchID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;
material = "wood";
stepSound = "wood";
