// Fence Config
id = config.getBlockId("fenceID");	   
name = "fence";
textureFile = "wood.png";
material = "wood";
stepSound = "wood";

// Oak Fence
displayName[0]   = "Oak Fence";   
textureIndexXN[0]   = 16;
textureIndexXP[0]   = 16;
textureIndexYN[0]   = 32;	   
textureIndexYP[0]   = 32;
textureIndexZN[0]   = 16;
textureIndexZP[0]   = 16;
drop[0] = config.getBlockId("fenceID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 2;
flammability[0] = 300;


// Acacia Wood Fence
displayName[1]   = "Acacia Wood Fence";   
textureIndexXN[1]   = 22;
textureIndexXP[1]   = 22;
textureIndexYN[1]   = 38;	   
textureIndexYP[1]   = 38;
textureIndexZN[1]   = 22;
textureIndexZP[1]   = 22;
drop[1] = config.getBlockId("fenceID") + ":1 1";
addToCreative[1]   = true;	   
creativeTab[1] = "decorations";
opacity[1] = 0;
hardness[1] = 2;
flammability[1] = 300;

// Acacia Plank Fence
displayName[2]   = "Acacia Plank Fence";   
textureIndexXN[2]   = 6;
textureIndexXP[2]   = 6;
textureIndexYN[2]   = 6;	   
textureIndexYP[2]   = 6;
textureIndexZN[2]   = 6;
textureIndexZP[2]   = 6;
drop[2] = config.getBlockId("fenceID") + ":2 1";
addToCreative[2]   = true;	   
creativeTab[2] = "decorations";
opacity[2] = 0;
hardness[2] = 2;
flammability[2] = 300;

// Fir Fence
displayName[3]   = "Fir Fence";   
textureIndexXN[3]   = 21;
textureIndexXP[3]   = 21;
textureIndexYN[3]   = 37;	   
textureIndexYP[3]   = 37;
textureIndexZN[3]   = 21;
textureIndexZP[3]   = 21;
drop[3] = config.getBlockId("fenceID") + ":3 1";
addToCreative[3]   = true;	   
creativeTab[3] = "decorations";
opacity[3] = 0;
hardness[3] = 2;
flammability[3] = 300;

// Fir Plank Fence
displayName[4]   = "Fir Plank Fence";   
textureIndexXN[4]   = 5;
textureIndexXP[4]   = 5;
textureIndexYN[4]   = 5;	   
textureIndexYP[4]   = 5;
textureIndexZN[4]   = 5;
textureIndexZP[4]   = 5;
drop[4] = config.getBlockId("fenceID") + ":4 1";
addToCreative[4]   = true;	   
creativeTab[4] = "decorations";
opacity[4] = 0;
hardness[4] = 2;
flammability[4] = 300;

// Jungle Fence
displayName[5]   = "Jungle Fence";   
textureIndexXN[5]   = 19;
textureIndexXP[5]   = 19;
textureIndexYN[5]   = 32;	   
textureIndexYP[5]   = 32;
textureIndexZN[5]   = 19;
textureIndexZP[5]   = 19;
drop[5] = config.getBlockId("fence_jungleID") + ":5 1";
addToCreative[5]   = true;	   
creativeTab[5] = "decorations";
opacity[5] = 0;
hardness[5] = 2;
flammability[5] = 300;

// Jungle Plank Fence
displayName[6]   = "Jungle Plank Fence";   
textureIndexXN[6]   = 3;
textureIndexXP[6]   = 3;
textureIndexYN[6]   = 3;	   
textureIndexYP[6]   = 3;
textureIndexZN[6]   = 3;
textureIndexZP[6]   = 3;
drop[6] = config.getBlockId("fenceID") + ":6 1";
addToCreative[6]   = true;	   
creativeTab[6] = "decorations";
opacity[6] = 0;
hardness[6] = 2;
flammability[6] = 300;

//Birch Fence
displayName[7]   = "Birch Fence";   
textureIndexXN[7]   = 18;
textureIndexXP[7]   = 18;
textureIndexYN[7]   = 32;	   
textureIndexYP[7]   = 32;
textureIndexZN[7]   = 18;
textureIndexZP[7]   = 18;
drop[7] = config.getBlockId("fenceID") + ":7 1";
addToCreative[7]   = true;	   
creativeTab[7] = "decorations";
opacity[7] = 0;
hardness[7] = 2;
flammability[7] = 300;

// Birch Plank Fence
displayName[8]   = "Birch Plank Fence";   
textureIndexXN[8]   = 2;
textureIndexXP[8]   = 2;
textureIndexYN[8]   = 2;	   
textureIndexYP[8]   = 2;
textureIndexZN[8]   = 2;
textureIndexZP[8]   = 2;
drop[8] = config.getBlockId("fenceID") + ":8 1";
addToCreative[8]   = true;	   
creativeTab[8] = "decorations";
opacity[8] = 0;
hardness[8] = 2;
flammability[8] = 300;

// Redwood Fence
displayName[9]   = "Redwood Fence";   
textureIndexXN[9]   = 20;
textureIndexXP[9]   = 20;
textureIndexYN[9]   = 36;	   
textureIndexYP[9]   = 36;
textureIndexZN[9]   = 20;
textureIndexZP[9]   = 20;
drop[9] = config.getBlockId("fenceID") + ":9 1";
addToCreative[9]   = true;	   
creativeTab[9] = "decorations";
opacity[9] = 0;
hardness[9] = 2;
flammability[9] = 300;

// Redwood Plank Fence
displayName[10]   = "Redwood Plank Fence";   
textureIndexXN[10]   = 4;
textureIndexXP[10]   = 4;
textureIndexYN[10]   = 4;	   
textureIndexYP[10]   = 4;
textureIndexZN[10]   = 4;
textureIndexZP[10]   = 4;
drop[10] = config.getBlockId("fenceID") + ":10 1";
addToCreative[10]   = true;	   
creativeTab[0] = "decorations";
opacity[10] = 0;
hardness[10] = 2;
flammability[10] = 300;

// Spruce Fence
displayName[11]   = "Spruce Fence";   
textureIndexXN[11]   = 17;
textureIndexXP[11]   = 17;
textureIndexYN[11]   = 32;	   
textureIndexYP[11]   = 32;
textureIndexZN[11]   = 17;
textureIndexZP[11]   = 17;
drop[11] = config.getBlockId("fenceID") + ":11 1";
addToCreative[11]   = true;	   
creativeTab[11] = "decorations";
opacity[11] = 0;
hardness[11] = 2;
flammability[11] = 300;

//Spruce Plank Fence
displayName[12]   = "Spruce Plank Fence";   
textureIndexXN[12]   = 1;
textureIndexXP[12]   = 1;
textureIndexYN[12]   = 1;	   
textureIndexYP[12]   = 1;
textureIndexZN[12]   = 1;
textureIndexZP[12]   = 1;
drop[12] = config.getBlockId("fenceID") + ":12 1";
addToCreative[12]   = true;	   
creativeTab[12] = "decorations";
opacity[12] = 0;
hardness[12] = 2;
flammability[12] = 300;
