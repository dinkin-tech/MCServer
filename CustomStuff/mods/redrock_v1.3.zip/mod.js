// Adds a property to the config file.
config.addBlockIdProperty("buttonID", 1801);
config.addBlockIdProperty("fenceID", 1802);
config.addBlockIdProperty("pressure_plateID", 1803);
config.addBlockIdProperty("redrock1ID", 1804);

// Gets the blocks's id from the config file.
var rrbuttonID = config.getBlockId("buttonID");
var rrfenceID = config.getBlockId("fenceID");
var rrpressure_plateID = config.getBlockId("pressure_plateID");
var redrock1ID = config.getBlockId("redrock1ID");


// Add aliases. 
// mod.addAlias(54, "chest");
// mod.addAliasWithMetadata(351, 1, "roseRed");
// mod.addAlias(chestID, "exampleChest");
mod.addAliasWithMetadata(254, 0, "redrock");
mod.addAliasWithMetadata(254, 1, "redcobble");
mod.addAliasWithMetadata(254, 2, "redbrick");
mod.addAlias(rrbuttonID, "rrbutton");
mod.addAlias(rrfenceID, "rrfence");
mod.addAlias(rrpressure_plateID, "rrpressureplate");
mod.addAliasWithMetadata(redrock1ID, 0, "mossystone");
mod.addAliasWithMetadata(redrock1ID, 1, "mossybrick");
mod.addAliasWithMetadata(redrock1ID, 2, "mossycobble");
mod.addAliasWithMetadata(redrock1ID, 3, "rrfurnace");
mod.addAlias(0, "air");
mod.addAlias(356, "rsrepeater");
mod.addAlias(76, "rstorch");
mod.addAlias(331, "rsdust");
mod.addAlias(275, "axe");
mod.addAlias(274, "pickaxe");
mod.addAlias(291, "hoe");
mod.addAlias(273, "shovel");
mod.addAlias(272, "sword");
mod.addAlias(69, "lever");
mod.addAlias(379, "brewingstand");
mod.addAlias(33, "piston");
mod.addAlias(23, "dispenser");
mod.addAlias(280, "stick");
mod.addAlias(369, "blazerod");
mod.addAlias(5, "wood");
mod.addAlias(265, "iron");
mod.addAlias(261, "bow");
mod.addAlias(295 , "seed");

// Add the chest components. 'exampleChest.js' is the file and 'chest' is the type.
// mod.addTileEntity("exampleChest.js", "chest");
// mod.addGui("exampleChest.js", "chest");
mod.addTileEntity("rrfurnace.js", "furnace");
mod.addGui("rrfurnace.js", "furnace");
mod.addBlock("button.js", "button");
mod.addBlock("fence.js", "fence");
mod.addBlock("pressure_plate.js", "pressurePlate");
mod.addBlock("redrock.js", "normal");

// Add a recipe for the chest. Here you can use your aliases.
// mod.addRecipe("exampleChest", 3, 3, "roseRed", "roseRed", "roseRed", "roseRed", "chest", "roseRed", "roseRed", "roseRed", "roseRed");
mod.addRecipe("rrbutton", 1, 2, "redrock", "redrock");
mod.addRecipe("rrpressureplate", 2, 1, "redrock", "redrock");
mod.addRecipe("rsrepeater", 3, 2, "rstorch", "rsdust", "rstorch", "redrock", "redrock", "redrock");
mod.addRecipe("rrfence", 3, 2, "redcobble", "redcobble", "redcobble", "redcobble", "redcobble", "redcobble");
mod.addRecipe("rrfurnace", 3, 3, "redcobble", "redcobble", "redcobble", "redcobble", "air", "redcobble", "redcobble", "redcobble", "redcobble");
mod.addRecipe("axe", 2, 3, "redcobble", "redcobble", "redcobble", "stick", "air", "stick");
mod.addRecipe("pickaxe", 3, 3, "redcobble", "redcobble", "redcobble", "air", "stick", "air", "air", "stick", "air");
mod.addRecipe("hoe", 2, 3, "redcobble", "redcobble", "air", "stick", "air", "stick");
mod.addRecipe("shovel", 1, 3, "redcobble", "stick", "stick");
mod.addRecipe("sword", 1, 3, "redcobble", "redcobble", "stick");
mod.addRecipe("lever", 1, 2, "stick", "redcobble");
mod.addRecipe("brewingstand", 3, 2, "air", "blazerod", "air", "redcobble", "redcobble", "redcobble");
mod.addRecipe("piston", 3, 3, "wood", "wood", "wood", "redcobble", "iron", "redcobble", "redcobble", "rsdust", "redcobble");
mod.addRecipe("dispenser", 3, 3, "redcobble", "redcobble", "redcobble", "redcobble", "bow", "redcobble", "redcobble", "rsdust", "redcobble");
mod.addRecipe("mossystone", 1, 2, "seed", "redrock");
mod.addRecipe("mossybrick", 1, 2, "seed", "redbrick");
mod.addRecipe("mossycobble", 1, 2, "seed", "redcobble");
