/* GUI */
name = "rrfurnace";
// 'exampleChestGui.png' is the same as '/ExampleMod/exampleChestGui.png'.
guiFile = "furnace.png";
