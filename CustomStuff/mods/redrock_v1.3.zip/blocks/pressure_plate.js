// Pressure Plate
id = config.getBlockId("pressure_plateID");
name = "rr_pressureplate";
displayName[0]   = "Pressure Plate";

// Texture Information
textureFile = "redrock.png"	   
textureIndexXN[0]   = 0;
textureIndexXP[0]   = 0;
textureIndexYN[0]   = 0;	   
textureIndexYP[0]   = 0;
textureIndexZN[0]   = 0;
textureIndexZP[0]   = 0;

drop[0] = config.getBlockId("pressure_plateID") + ":0 1";
addToCreative[0]   = true;	   
opacity[0] = 0;
hardness[0] = 15;






