// Button Config
id = config.getBlockId("buttonID");	   
name = "rr_button";
displayName[0]   = "Button";   

// Texture Information
textureFile = "redrock.png";
textureIndexXN[0]   = 0;
textureIndexXP[0]   = 0;
textureIndexYN[0]   = 0;	   
textureIndexYP[0]   = 0;
textureIndexZN[0]   = 0;
textureIndexZP[0]   = 0;

drop[0] = config.getBlockId("buttonID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "redstone";
opacity[0] = 0;
hardness[0] = 15;