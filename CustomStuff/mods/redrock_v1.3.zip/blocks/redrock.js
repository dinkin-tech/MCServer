// Red Rock
id = config.getBlockId("redrock1ID");
name = "redrock1";
textureFile = "redrock.png";

// Meta 0 - Mossy Red Rock
textureIndexYN[0] = 3;
textureIndexYP[0] = 3;
textureIndexXN[0] = 3;
textureIndexXP[0] = 3;
textureIndexZN[0] = 3;
textureIndexZP[0] = 3;
drop[0] = config.getBlockId("redrock1ID") + ":0 1";
addToCreative[0]= true;	   
displayName[0]= "Mossy Stone";	   
hardness[0] = 15;

// Meta 1 - Mossy Red Brick
textureIndexYN[1] = 4;
textureIndexYP[1] = 4;
textureIndexXN[1] = 4;
textureIndexXP[1] = 4;
textureIndexZN[1] = 4;
textureIndexZP[1] = 4;
drop[1] = config.getBlockId("redrock1ID") + ":1 1";
addToCreative[1]= true;	   
displayName[1]= "Mossy Brick";	   
hardness[1] = 15;

// Meta 2 - Mossy Cobble
textureIndexYN[2] = 5;
textureIndexYP[2] = 5;
textureIndexXN[2] = 5;
textureIndexXP[2] = 5;
textureIndexZN[2] = 5;
textureIndexZP[2] = 5;
drop[2] = config.getBlockId("redrock1ID") + ":2 1";
addToCreative[2]= true;	   
displayName[2]= "Mossy Cobble";	   
hardness[2] = 15;

// Metadata 3
textureIndexYN[3] = 9;
textureIndexYP[3] = 9;
textureIndexZN[3] = 7;	   
textureIndexXP[3] = 7;
textureIndexXN[3] = 7;
textureIndexZP[3] = 7;
drop[3]= config.getBlockId("redrock1ID") + ":3 1";	   
addToCreative[3]= true;	   
displayName[3]= "Red Rock Furnace";   
hasTileEntity[3] = true;
tileEntity[3] = "rrfurnace";	   
onActivated[3]= "player.openGui('rrfurnace', position); result = true;";
hardness[3] = 15;
