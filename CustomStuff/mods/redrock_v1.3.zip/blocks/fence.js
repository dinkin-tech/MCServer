// Fence Config
id = config.getBlockId("fenceID");	   
name = "rr_fence";
displayName[0]   = "Fence";   

// Texture Information
textureFile = "redrock.png";
textureIndexXN[0]   = 2;
textureIndexXP[0]   = 2;
textureIndexYN[0]   = 2;	   
textureIndexYP[0]   = 2;
textureIndexZN[0]   = 2;
textureIndexZP[0]   = 2;

drop[0] = config.getBlockId("fenceID") + ":0 1";
addToCreative[0]   = true;	   
creativeTab[0] = "decorations";
opacity[0] = 0;
hardness[0] = 15;
