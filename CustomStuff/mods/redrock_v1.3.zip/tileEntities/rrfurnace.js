/* Tile entity */
name = "rrfurnace";
ticksToSmelt = 200;
